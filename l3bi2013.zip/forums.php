{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template forums}
  {show menu}
  <div id="main_contents">
    <h2>{$lang['forums']}</h2>
    <div class="content_box">
      <div class="tbl_header">
        <p style="width: 370px;">{$lang['forum']}</p>
        <p style="width: 50px;">{$lang['topics']}</p>
        <p style="width: 50px;">{$lang['replies']}</p>
        <p style="width: 108px;">{$lang['last_reply']}</p>
      </div>
  {foreach $txt['categories'] as $categories}
      <div class="tbl">
        <p class="bold">{$categories['cat_title']}</p>
      </div>
      {foreach $txt['forums'][$categories['cat_id']] as $forums}
      <div class="tbl">
        <p style="width: 26px;">
      {if $forums['new']}
          <img src="images/forum_new.png" class="forum_icon" title="{$lang['new']}" alt="{$lang['new']}" />
      {else}
          <img src="images/forum_read.png" class="forum_icon" title="{$lang['read']}" alt="{$lang['read']}" />
      {/if}
        </p>
        <div style="width: 340px;">
          <p><a href="forums.php?a=forum&amp;f={$forums['forum_id']}">{$forums['title']}</a></p>
          <p>{$forums['description']}</p>
        </div>
        <p class="center" style="width: 50px;">{$forums['topics']}</p>
        <p class="center" style="width: 50px;">{$forums['replies']}</p>
        <p class="center" style="width: 108px;">{$forums['last_reply']}</p>
      </div>
    {/foreach}
  {/foreach}
    </div>
  </div>
{/template}

{template forum}
  {show menu}
  <div id="main_contents">
    <h2><a href="forums.php">{$lang['forums']}</a> &gt; {$txt['forum']['title']}</h2>
    <div class="content_box">
  {if $txt['forum']['permission']}
      <div style="float: left;">
        <a href="forums.php?a=new_topic&amp;f={$txt['forum']['forum_id']}" class="button">{$lang['new_topic']}</a>
      </div>
  {/if}
      <div class="pagination" style="float: right;">
        {$txt['navigation']}
      </div>
      <div class="clear"></div>
      <div class="tbl_header">
        <p style="width: 370px;">{$lang['topic']}</p>
        <p style="width: 50px;">{$lang['replies']}</p>
        <p style="width: 50px;">{$lang['views']}</p>
        <p style="width: 110px;">{$lang['last_reply']}</p>
      </div>
  {if empty($txt['topics'])}
      <p class="center">{$lang['no_posts']}</p>
  {else}
    {foreach $txt['topics'] as $topics}
      <div class="tbl">
        <p style="width: 18px;">
      {if $topics['status'] == 1}
          <img src="images/topic_new.png" class="post_icon" alt="{$lang['new']}" title="{$lang['new']}" />
      {elseif $topics['status'] == 2}
          <img src="images/locked.png" class="post_icon" alt="{$lang['locked']}" title="{$lang['locked']}" />
      {else}
          <img src="images/topic.png" class="post_icon" alt="" />
      {/if}
        </p>
        <p style="width: 348px;">
      {if $topics['sticky'] == 1}
          {$lang['sticky']}:
      {/if}
          <a href="forums.php?a=topic&amp;t={$topics['topic_id']}">{$topics['title']}</a>
        </p>
        <p class="center" style="width: 50px;">{$topics['replies']}</p>
        <p class="center" style="width: 50px;">{$topics['views']}</p>
        <p class="center" style="width: 110px;">{$topics['last_reply']}</p>
      </div>
    {/foreach}
  {/if}
  {if $txt['forum']['permission']}
      <div style="float: left;">
        <a href="forums.php?a=new_topic&amp;f={$txt['forum']['forum_id']}" class="button">{$lang['new_topic']}</a>
      </div>
  {/if}
      <div class="pagination" style="float: right;">
        {$txt['navigation']}
      </div>
      <div class="clear"></div>
      <p><img src="images/topic.png" width="16" height="16" alt="" /> - {$lang['read']}</p>
      <p><img src="images/topic_new.png" width="16" height="16" alt="" /> - {$lang['new']}</p>
      <p><img src="images/locked.png" width="16" height="16" alt="" /> - {$lang['locked']}</p>
    </div>
  </div>
{/template}

{template topic}
  {show menu}
  <div id="main_contents">
    <h2><a href="forums.php">{$lang['forums']}</a> &gt; <a href="forums.php?a=forum&amp;f={$txt['topic']['forum_id']}">{$txt['topic']['forum_title']}</a> &gt; {$txt['topic']['topic_title']}</h2>
    <div class="content_box">
  {if $txt['topic']['permission']}
      <div style="float: left;">
        <a href="forums.php?a=new_reply&amp;t={$txt['topic']['topic_id']}" class="button">{$lang['reply']}</a>
      </div>
  {/if}
      <div class="pagination" style="float: right;">
        {$txt['navigation']}
      </div>
      <div class="clear"></div>
  {foreach $txt['replies'] as $reply}
      <div class="post forum_post">
        <div class="content">
          <p class="header">
            <img src="images/message.png" width="10" height="10" alt="" />
            {$reply['title']}
            <span>- {$reply['date_posted']}</span>
          </p>
          <div class="message">{$reply['message']}</div>
          <p class="footer">
      {if $reply['poster_id'] == $session->user_id || $session->user_group == 2}
            <a href="forums.php?a=edit_post&amp;r={$reply['reply_id']}" class="button">{$lang['edit']}</a>
            <a href="forums.php?a=delete&amp;r={$reply['reply_id']}" onclick="return confirm_delete();" class="button">{$lang['delete']}</a>
      {/if}
      {if $txt['topic']['permission']}
            <a href="forums.php?a=new_reply&amp;r={$reply['reply_id']}" class="button">{$lang['reply']}</a>
      {/if}
          </p>
        </div>
        <div class="poster">
          <p><img src="{$reply['avatar']}" alt="" /></p>
          <p class="user">{$reply['username']}</p>
          <p>{$lang['played']}: {$reply['user_played']}</p>
          <p>{$lang['comments']}: {$reply['user_comments']}</p>
          <p>{$lang['joined']}: {$reply['user_joined']}</p>
    {if $session->user_group == 2}
          <p>({$reply['poster_ip']})</p>
    {/if}
        </div>
      </div>
  {/foreach}
  {if $txt['topic']['permission']}
      <div style="float: left;">
        <a href="forums.php?a=new_reply&amp;t={$txt['topic']['topic_id']}" class="button">{$lang['reply']}</a>
      </div>
  {/if}
      <div class="pagination" style="float: right;">
        {$txt['navigation']}
      </div>
      <div class="clear"></div>
  {if $session->user_group == 2}
      <form action="" method="post">
        <select name="moderate_action">
          <option value="lock">{$lang['lock']}</option>
          <option value="sticky">{$lang['sticky_not']}</option>
          <option value="delete">{$lang['delete']}</option>
        </select>
        <input type="submit" value="{$lang['submit']}" name="submit_moderate" />
      </form>
  {/if}
    </div>
  </div>
{/template}

{template post}
  {show menu}
  <div id="main_contents">
    <h2><a href="forums.php">{$lang['forums']}</a> &gt; {$txt['post_title']}</h2>
    <div class="content_box">
      <form method="post" action="">
  {if isset($txt['preview'])}
        <div class="post forum_post">
          <div class="content">
            <p class="header">
              <img src="images/message.png" width="10" height="10" alt="" />
              {$txt['preview']['title']}
            </p>
            <div class="message">{$txt['preview']['message']}</div>
          </div>
          <div class="poster">
            <p><img src="{$txt['avatar']}" alt="" /></p>
            <p class="user">{$txt['username']}</p>
            <p>{$lang['played']}: {$txt['played']}</p>
            <p>{$lang['comments']}: {$txt['comments']}</p>
          </div>
        </div>
    {/if}
    {if isset($txt['error'])}
        <p class="error">{$txt['error']}</p>
    {/if}
        <div class="line">
          <p class="left">{$lang['title']}:</p>
          <p><input type="text" name="title" maxlength="200" value="{$txt['message']['title']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['message']}:</p>
          <div>
            <div id="bb_code"></div>
            <p><textarea name="message" id="message" class="post">{$txt['message']['message']}</textarea></p>
          </div>
        </div>
        <div class="center">
          <input type="submit" name="submit_post" value="{$lang['submit']}" />
          <input type="submit" name="preview_post" value="{$lang['preview']}" />
        </div>
      </form>
      <script type="text/javascript">
    bb_code.attach("bb_code", "message");
      </script>
    </div>
  {if isset($txt['recent'])}
    <h2>{$lang['latest_responses']}</h2>
    <div class="content_box">
    {foreach $txt['recent'] AS $recent}
      <div class="post forum_post">
        <div class="content">
          <p class="header">
            <img src="images/message.png" width="10" height="10" border="0" alt="" />
            {$recent['title']}
            <span>- {$recent['date_posted']}</span>
          </p>
          <p>{$recent['message']}</p>
        </div>
        <div class="poster">
          <p class="user">{$recent['username']}</p>
        </div>
      </div>
    {/foreach}
    </div>
  {/if}
  </div>
{/template}