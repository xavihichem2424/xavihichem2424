$(document).ready(function () {
	jQuery(".but_txt").hover(function() {
		jQuery(this).stop().animate({ marginTop: "2px" }, 888,'easeOutElastic');
		},function(){
			jQuery(this).stop().animate({ marginTop: "0px" }, 888,'easeOutElastic');			
		});
	jQuery("#cat1 ul li").hover(function() {
		jQuery(this).stop().animate({ marginRight: "15px" }, 888,'easeOutElastic');
		},function(){
			jQuery(this).stop().animate({ marginRight: "19px" }, 888,'easeOutElastic');			
		});

	$(window).scroll(function() {
		if($(this).scrollTop() != 0) {
			$('.top').fadeIn();	
		} else {
			$('.top').fadeOut();
		}
	});
	$('.top').click(function() {
		$('body,html').animate({scrollTop:0},800);
	});
});	
$(function () {
    $(".top").stop().fadeTo(250, 1);
    $(".top").hover(function () {
        $(this).stop().fadeTo(250, 0.6);
    }, function () {
        $(this).stop().fadeTo(250, 1);
    });
});