{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template cup}
  
  <div id="main_contents_cup">
    <h2>{$lang['cups']}</h2>
    <div class="content_box">
      {if $cup['can_join']}
      <p><button id="join_cup">{$lang['join_cup']}</button></p>
      {/if}
      <div class="line">
        <p class="left">{$lang['name']}:</p>
        <p>{$cup['name']}</p>
      </div>
      <div class="line">
        <p class="left">{$lang['creator']}:</p>
        <p><a href="{$cup['user_url']}">{$cup['username']}</a></p>
      </div>
      <div class="line">
        <p class="left">{$lang['created']}:</p>
        <p>{$cup['time_created']}</p>
      </div>
      <div class="line">
        <p class="left">{$lang['closing']}:</p>
        <p>{$cup['time_end']}</p>
      </div>
      <h4>{$lang['results']}</h4>
      <div class="cup_line bold">
        <p class="position padding_top">#</p>
        <p class="user padding_top">{$lang['user']}</p>
        {foreach $cup['games'] AS $file}
        <p><a href="{$file['url']}"><img src="{$file['image']}" alt="{$file['title']}" title="{$file['title']}" /></a></p>
        {/foreach}
        <p class="padding_top">{$lang['total']}</p>
      </div>
        {foreach $results AS $result}
      <div class="cup_line">
        <p class="position">{$result['position']}</p>
        <p class="user"><a href="{$result['url']}">{$result['username']}</a></p>
        {foreach $result['points'] AS $points}
        <p>{$points}</a></p>
        {/foreach}
        <p>{$result['total_points']}</p>
      </div>
        {/foreach}
    </div>
    <script type="text/javascript">
	cup.init({$cup['id']});
	</script>
  </div>
{/template}

{template all_cups}
  
  <div id="main_contents_cup">
      {if $settings['cups_create']}
    <h2>{$lang['cups']}</h2>
    <div class="content_box">
      <p><a href="cup.php?a=create" class="button">{$lang['create_cup']}</a></p>
    </div>
      {/if}
    <h2>{$lang['live_cups']}</h2>
    <div class="content_box">
      {if !empty($live['cups'])}
      <div id="live_cups">
        {show cups_live}
      </div>
      {else}
      <p class="center">{$lang['no_cups']}</p>
      {/if}
    </div>
    <h2>{$lang['closed_cups']}</h2>
    <div class="content_box">
      {if !empty($closed['cups'])}
      <div id="closed_cups">
        {show cups_closed}
      </div>
      {else}
      <p class="center">{$lang['no_cups']}</p>
      {/if}
    </div>
    <div class="column_left">
      <h2>{$lang['champions']}</h2>
      <div class="content_box">
        <ol class="cup_top_users">
        {foreach $users['champion'] AS $user}
          <li>
            <span>{$user['cups_number']} {$lang['top_wins']}</span>
            <a href="{$user['url']}">{$user['username']}</a>
          </li>
        {/foreach}
        </ol>
      </div>
    </div>
    <div class="column_right">
      <h2>{$lang['most_active']}</h2>
      <div class="content_box">
        <ol class="cup_top_users">
        {foreach $users['active'] AS $user}
          <li>
            <span>{$user['cups_number']} {$lang['cups_s']}</span>
            <a href="{$user['url']}">{$user['username']}</a>
          </li>
        {/foreach}
        </ol>
      </div>
    </div>
    <div class="clear"></div>
    <script type="text/javascript">
	cups.init();
	</script>
  </div>
{/template}

{template cups_live}
        {foreach $live['cups'] AS $cup}
      <p class="cup">
        <span class="end_time">{$lang['closing']}: {$cup['time_end']}</span>
        <span class="games">{$cup['games']}</span>
        <a href="{$settings['siteurl']}/cup.php?id={$cup['cup_id']}">{$cup['name']}</a>
      </p>
        {/foreach}
      <div class="arrow_nav">
          {if $live['previous'] > 0}
        <a href="" class="previous" id="live_page_{$live['previous']}">&lt; {$lang['previous']}</a>
          {/if}
          {if $live['next'] > 0}
        <a href="" class="next" id="live_page_{$live['next']}">{$lang['next']} &gt;</a>
          {/if}
      </div>
{/template}

{template cups_closed}
        {foreach $closed['cups'] AS $cup}
      <p class="cup">
        <span class="winner">{$lang['winner']}: <a href="{$cup['user_url']}">{$cup['username']}</a></span>
        <span class="games">{$cup['games']}</span>
        <a href="{$settings['siteurl']}/cup.php?id={$cup['cup_id']}">{$cup['name']}</a>
      </p>
        {/foreach}
      <div class="arrow_nav">
          {if $closed['previous'] > 0}
        <a href="" class="previous" id="closed_page_{$closed['previous']}">&lt; {$lang['newer']}</a>
          {/if}
          {if $closed['next'] > 0}
        <a href="" class="next" id="closed_page_{$closed['next']}">{$lang['older']} &gt;</a>
          {/if}
      </div>
{/template}

{template create_cup}
  
  <div id="main_contents_cup">
    <h2>{$lang['create_cup']}</h2>
    <div class="content_box">
      <form id="create_cup_form" method="post" action="">
        <div class="line">
          <p class="left">{$lang['name']}:</p>
          <p><input type="text" name="name" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['duration']}:</p>
          <p>
            <select name="duration">
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
              <option value="4">4</option>
              <option value="5">5</option>
              <option value="6">6</option>
              <option value="7">7</option>
            </select>
            {$lang['days']}
          </p>
        </div>
        <h4>{$lang['games']}</h4>
        <div><select id="games_selection"></select></div>
        <div id="cup_games"></div>
        <p class="center"><input type="submit" value="{$lang['submit']}" />
      </form>
      <script type="text/javascript">
		create_cup.init({$games});
      </script>
    </div>
  </div>
{/template}