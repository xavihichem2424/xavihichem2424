{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}
{template overall_header}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="shortcut icon" href="{$settings['siteurl']}/favicon.ico" type="image/x-icon" />
<title>{(isset($template->title) ? $template->title .' - '. $settings['sitename'] : $settings['sitename'])}</title>
<link rel="alternate" type="application/rss+xml" title="{$lang['rss_newest_files']} (RSS 2.0)" href="{$settings['siteurl']}/rss.php?r=newest&amp;l=10" />
<link rel="stylesheet" type="text/css" href="{$settings['siteurl']}/templates/l3bi2013/style.css" />
<meta name="description" content="{$template->description}" />
<meta name="keywords" content="{$template->keywords}" />

<script type="text/javascript">
  var siteurl = "{$settings['siteurl']}/";
  {$template->load_js_lang()}
</script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/jquery.js"></script>
  <script type="text/javascript" src="{$settings['siteurl']}/templates/l3bi2013/template.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/global.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/swfobject.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/templates/l3bi2013/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/templates/l3bi2013/js/rounq.js"></script>
<script src="{$settings['siteurl']}/templates/l3bi2013/js/SpryTabbedPanels.js" type="text/javascript"></script>
{$template->header}
<!--[if IE]>
<style type="text/css">
.TabbedPanels {
padding: 0px;
}
.browse_file, .file {height: 175px;}
.file3 {height: 175px;}
.in_txt { padding-top:8px !important; height:17px !important; padding-bottom:0 !important;}
</style>
<![endif]-->
</head>

{/template}

{template header}
<body>
<div id="page">
	<div id="main">
    	<div id="header">
        	<a href="{$settings['siteurl']}/" class="logo_link" rel="nofollow"></a>
            <a rel="nofollow" href="{$settings['siteurl']}/" class="home_bu but_txt" title="{$settings['sitename']}">الرئيسية</a>
            <form action="{$settings['siteurl']}/search.php" method="post">
              	<input name="t" class="search in_txt" value="ادخل كلمة البحث..."  />
                <input type="submit" class="but_txt search_bu" value="بحث" />
              </form>
            {if $session->info['status'] == 1}
              <a rel="nofollow" href="{$settings['siteurl']}/login.php?a=logout" class="reg_bu but_txt">الخروج</a>
							<a class="usercp but_txt" href="{$settings['siteurl']}/usercp.php">التحكم</a>
							<a class="favgame but_txt" href="{$settings['siteurl']}/usercp.php?a=favourites" id="favourites_link">المفضلة <img src="{$settings['siteurl']}/templates/l3bi2013/images/down_arrow.png" alt="" /> </a>
							<span class="in_txt userna">{$lang['welcome_username']}</span>
              
              {else}
              <a rel="nofollow" href="{$settings['siteurl']}/profile.php?a=register" class="reg_bu but_txt">التسجيل</a>
          <form action="{$settings['siteurl']}/login.php" method="post">
                    <input type="text" name="username" class="username in_txt" id="username" value="أسم العضو" />
                    <input type="password" name="password" class="password in_txt" id="password" value="password" />
                    <input type="submit" name="submit" class="but_txt login_bu" value="دخول" />
              </form>
          {/if}
        </div><!--End header-->
            <div id="content">
        	<div id="right_column">
        	<div id="cat1">
            <div class="cat_t">
            <div class="cat_b">
            	<ul>
                            	  {foreach $menu->categories as $category}
      <li{($category['first']?' class="first"':'')}><a href="{$category['url']}"> <img src="{$settings['siteurl']}/templates/l3bi2013/images/{$category['id']}.png" width="25" height="25"  alt="{$category['title']}"  title="{$category['title']}'" />{$category['title']}</a></li>
  {/end}
		             
                            </ul>
                </div>
                </div>
            </div><!--End cat1-->
            <div id="banner_catbelow">
                	<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner3.jpg" alt="" />
                </div><!--End banner_catbelow-->
            </div><!--End right_column-->
				<div id="left_cplumn">

{/template}

{template footer}
  <div class="clear"></div>
 </div><!--End left_cplumn-->
  </div><!--End content-->
    </div><!--End main-->
	<div id="footer">
    	<div id="footer_c">
        	<div class="footer_copyright">جميع الحقوق محفوظة لموقع <a href="#">العاب رونق</a></div><!--End -->
            <a class="rounq" href="http://www.rounq.com/" title="تصميم رونق" target="_blank"></a>
            <a href="#" class="top" style="opacity: 1;"></a>
        </div><!--End footer_c-->
    </div><!--End footer-->
</div><!--End page-->
<script type="text/javascript">
$('#password').focus(function () {
    if (this.value == "password")
        this.value = "";    
}).blur(function () {
    if (this.value == "")
        this.value = "password";    
});
$('#username').focus(function () {
    if (this.value == "أسم العضو")
        this.value = "";    
}).blur(function () {
    if (this.value == "")
        this.value = "أسم العضو";    
});
$('.search').focus(function () {
    if (this.value == "ادخل كلمة البحث...")
        this.value = "";    
}).blur(function () {
    if (this.value == "")
        this.value = "ادخل كلمة البحث...";    
});
</script>
</body>

</html>
{/template}



{template index}
 <div class="top_banner">
	<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner1.jpg" alt="" />
	</div>
    {if $settings['most_popular_list'] == 1}
<div class="pouplargame">
      <div class="pouplar_game">
      
    {foreach $menu->most_popular AS $popular}
    <div class="file3">
          <div class="icon3">
        <a href="{$popular['url']}"><img src="{$popular['image']}" width="150" height="115" title="{$popular['title']}" alt="{$popular['title']}" border="0" /></a>
        </div>
            <p class="link3"><a href="{$popular['url']}">{$popular['title']}</a></p>
          </div>

  
    {/foreach}
      
  </div></div>
  {/if}
  {if $settings['newest_list'] == 1}
<div class="new_game">
<div id="right_banner">
<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner2.jpg" alt="" />
</div>
    {foreach $menu->newest AS $new}
    	<div class="file3">
          <div class="icon3">
        <a rel="nofollow" href="{$new['url']}"><img src="{$new['image']}" width="150" height="115" title="{$new['title']}" alt="{$new['title']}" border="0" /></a>
        </div>
            <p class="link3"><a href="{$new['url']}">{$new['title']}</a></p>
          </div>
    {/foreach}
      <div class="newest3">  
            <div class="clear"></div>
            </div>  
  </div>
  {/if}  
{/template}

{template rss_feeds}
 
  <div id="main_contents">
    <h2>{$lang['rss_feed']}</h2>
    <div class="content_box">
      <p>{$lang['rss_feed_introduction']}</p>
      <p>- <a href="{$settings['siteurl']}/rss.php?r=mostpopular&amp;l=10">{$lang['rss_most_popular_files']}</a></p>
      <p>- <a href="{$settings['siteurl']}/rss.php?r=newest&amp;l=10">{$lang['rss_newest_files']}</a></p>
      <p>- <a href="{$settings['siteurl']}/rss.php?r=news&amp;l=10">{$lang['rss_news']}</a></p>
      {foreach $categories as $category}
      <p>- <a href="{$settings['siteurl']}/rss.php?r=category&amp;id={$category['id']}&amp;l=10">{$category['name']}</a></p>
      {/foreach}
    </div>
  </div>
{/template}

{template redirect($redirect_url, $redirect_message)}
  {show overall_header}
<div id="redirection_box">
  <p>{$redirect_message}</p>
  <p>{$lang['if_not_redirected']}</p>
  <script type="text/javascript">
  setTimeout("window.location = '{$redirect_url}';", 1000);
  </script>
</div>
</body>
</html>
{/template}



{template blank_page($title,$content)}
  <div id="main_contents">
    <h2>{$title}</h2>
    <div class="content_box">
      {$content}
    </div>
  </div>
{/template}