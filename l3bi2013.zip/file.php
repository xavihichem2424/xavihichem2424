{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template file}

  <div id="main_contents">
  <div style="clear: both; text-align: center; margin:0 0 10px 20px;">
<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner2.jpg" alt="" />
</div>
  <div id="share_button" style="text-align:center; padding-bottom:3px; margin-left:20px;">
<iframe src="http://www.facebook.com/plugins/like.php?href={$file['share_url']}&amp;title={$file['share_title']}&amp;layout=box_count&amp;show_faces=false&amp;width=450&amp;action=like&amp;colorscheme=light&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:70px; height:62px;" ></iframe>
<a href="https://twitter.com/share" class="twitter-share-button" data-count="vertical">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
<script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>

<div class="g-plusone" data-size="tall"></div>
</div>
  
  {if $settings['before_file_ad']}
    <div id="file_ad_box">
      <h2>{$lang['sponsor']}</h2>
      <div>
        <div><img src="{$settings['siteurl']}/templates/l3bi2013/images/banner2.jpg" alt="" /></div>
        <div id="ad_loader"><div></div></div>
        <p id="no_wait"><a href="">{$lang['click_wait']}</a></p>
      </div>
    </div>
  {/if}
    <div id="file_box">
    <h2 class="cat_brea" style="margin-top:10px;"><a href="{$settings['siteurl']}/">{$settings['sitename']} </a><span>&gt;</span>  <a href="{$file['cat_url']}">{$file['cat_title']}</a><span>&gt;</span> {$file['title']}</h2>
      <div class="content_box center">
        {$file['play_file']}
      </div>
      
    </div>
    <div id="file_tabs"></div>
    <div style="margin-top: 20px;">
</div> 
    <div id="TabbedPanels1" class="TabbedPanels">
	   <ul class="TabbedPanelsTabGroup"> 
  <li class="TabbedPanelsTab" >معلومات الملف</li> 
  <li class="TabbedPanelsTab" >شارك اصحابك</li> 
</ul>
<div class="TabbedPanelsContentGroup">
<div class="TabbedPanelsContent">
<span class="titlsco" style="float:right;">{$file['title']}</span>

<img style="float:right;" src="{$settings['siteurl']}/images/full_screen.png" id="full_screen" title="{$lang['full_screen']}" alt="{$lang['full_screen']}" />

 {if $session->user_status == 1}
        <button id="favorite" style="float:right;">{($file['favourite'] ? $lang['remove_favorite'] : $lang['favorite'])}</button>
        
        {/if}
        
	<div style="float:right; clear:none;">ما رأيك باللعبة ؟ <span id="file_rating">{$file['rating']}</span></div>
	<h2 style="clear:both;">الوصف</h2>
	<p class="file_info2">{$file['description']}</p>
	<div style="clear:both; padding:5px;"></div>
	<span class="file_info">{$lang['played']}: {$file['played']}</span>|
		   <span class="file_info">{$lang['added']}: {$file['added']}'</span>
		   <div style="clear:both; padding:5px;"></div>
		   <p class="keywords">{$file['tags']}</p>

</div> 
<div class="TabbedPanelsContent"><p>
           <a href="http://twitter.com/home?status={$file['share_message']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/twitter.png" title="Twitter" alt="Twitter" /></a>
          <a href="http://digg.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/digg.png" title="Digg" alt="Digg" /></a>
          <a href="http://www.facebook.com/sharer.php?u={$file['share_url']}&amp;t={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/facebook.png" title="Facebook" alt="Facebook" /></a>
          <a href="http://del.icio.us/post?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/delicious.png" title="Delicious" alt="Delicious" /></a>
          <a href="http://www.stumbleupon.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/stumbleupon.png" title="StumbleUpon" alt="StumbleUpon" /></a>
        </p>

      </div>
	   </div>
	   </div>
       <div style="float:right; margin:50px 10px 20px 0;"><img src="{$settings['siteurl']}/templates/l3bi2013/images/banner2.jpg" alt="" /></div>
       
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>
       <div class="clear"></div>
  {if $settings['related_files']}
    <div>
    {foreach $txt['related'] as $number => $related}
      <div class="browse_file">
        <div class="icon">
 
          <a href="{$related['url']}"><img src="{$related['image']}" width="150" height="115" title="{$related['title']}" alt="{$related['title']}" border="0" /></a>
          <p class="link"><a href="{$related['url']}">{$related['title']}</a></p>
        </div>
        
      </div>
      {if $number % 4 == 3}
      <div class="separator"></div>
      {/if}
    {/foreach}
      <div class="clear"></div>
    </div>
  {/if}
  <script type="text/javascript">
		init_file_info({$file['id']}, {$file['rating']}, {$settings['rate']}, {$settings['before_file_ad_time']});
    </script>
<div class="fb-comments" data-href="{$file['share_url']}" data-width="700" data-num-posts="10"></div><div><div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=590189181007374";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script></div>
  {if $settings['comments'] != 0}
    <h2>
      {$lang['file_comments']}:
    {if $session->user_group == 2}
      [<a href="{$settings['siteurl']}/admin/files.php#files_tabs/6/comments/{$file['id']}">{$lang['edit']}</a>]
    {/if}
    </h2>
    <div id="to_comments" class="content_box">
    {if $settings['comments'] == 1 || $settings['comments'] == 2 && $session->user_status == 1}
      <form action="" method="post" id="comment_form">
        <div id="bb_code"></div>
        <p><textarea name="comment" id="comment" role="" rows="" class="comment"></textarea></p>
      {if $settings['image_verification'] == 1}
        <p id="comment_verification_field"></p>
      {/if}
        <p><input type="submit" value="{$lang['add_comment']}" /></p>
      </form>
      <script type="text/javascript">
    bb_code.attach_emoticons("bb_code", "comment");
      </script>
    {else}
      <p class="bold">{$lang['login_to_comment']}</p>
    {/if}
      <div class="separator"></div>
      <div id="comments"></div>
    </div>
    <script type="text/javascript">
  comments.data = {$txt['comments']};
  comments.init({$file['id']}, {$settings['max_comments']});
    </script>
  {/if}
  </div>
{/template}

{template scoreboard}
  {if empty($scores['first'])}
      <p class="center">{$lang['no_scores_yet']}</p>
  {else}
      <div class="first">
        <a href="{$scores['first']['url']}">
          <img src="{$scores['first']['avatar']}" alt="" />
          {$scores['first']['username']}
        </a>
        <p>{$lang['score']}: {$scores['first']['score']}</p>
      </div>
      <div class="others">
    {foreach $scores['scores'] as $score}
      <div class="score_line{($score['me'] ? ' me':'')}">
        <p class="position">{$score['position']}</p>
        <p class="user"><a href="{$score['url']}">{$score['username']}</a></p>
        <p class="score">{$score['score']}</p>
      </div>
    {/end}
    {if $scores['all']}
        <p class="center"><button id="all_scores">{$lang['all_scores']}</button></p>
    {/if}
      </div>
      <div class="clear"></div>
  {/if}
{/template}

{template frame}
  {show overall_header}
<body>

<div id="file_frame_info">
  <ul class="tab_menu" id="file_tabs">
    <li><a href="" class="selected">{$lang['file_info']}</a></li>
    <li><a href="" class="selected">{$lang['favorite']}</a></li>
    <li><a href="">{$lang['share']}</a></li>
  {if $settings['report_broken'] == 1}
    <li><a href="">{$lang['report_broken']}</a></li>
  {/if}
  </ul>
  <div class="content_box">
    <div class="pos_relative">
      <img src="{$settings['siteurl']}/images/full_screen.png" id="full_screen" title="{$lang['full_screen']}" alt="{$lang['full_screen']}" />
      <p class="bold">
          {$file['title']}
  {if $session->user_group == 2}
          [<a href="{$settings['siteurl']}/admin/files.php#files_tabs/5/file/{$file['id']}">{$lang['edit']}</a>]
  {/if}
      </p>
      <p id="file_rating">{$file['rating']}</p>
      <p>{$file['description']}</p>
      <p>{$file['tags']}</p>
      <p class="file_info">{$lang['played']}: {$file['played']}</p>
      <p class="file_info">{$lang['added']}: {$file['added']}</p>
      <p class="file_info">{$lang['added_by']}: {$file['added_by']}</p>
      <div class="clear"></div>
      <a href="{$settings['siteurl']}">{$lang['back_to_website']}</a>
    </div>
    <div>
        {if $session->user_status == 1}
      <button id="favorite">{($file['favourite'] ? $lang['remove_favorite'] : $lang['favorite'])}</button>
        {else}
      <p class="bold">{$lang['please_in_favorite']}</p>
        {/if}
        {if !empty($txt['like'])}
      <h4>{$lang['people_favorite']}:</h4>
          {foreach $txt['like'] as $user}
      <a href="{$user['url']}">{$user['username']}</a>
          {/foreach}
        {/if}
    </div>
    <div>
      <p>
        <a href="http://twitter.com/home?status={$file['share_message']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/twitter.png" title="Twitter" alt="Twitter" /></a>
        <a href="http://digg.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/digg.png" title="Digg" alt="Digg" /></a>
        <a href="http://www.facebook.com/sharer.php?u={$file['share_url']}&amp;t={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/facebook.png" title="Facebook" alt="Facebook" /></a>
        <a href="http://del.icio.us/post?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/delicious.png" title="Delicious" alt="Delicious" /></a>
        <a href="http://www.stumbleupon.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/stumbleupon.png" title="StumbleUpon" alt="StumbleUpon" /></a>
      </p>
        {if $settings['add_to_website'] != 0}
      <h4>{$lang['add_to_your_website']}:</h4>
      <p><textarea class="comment" onFocus="this.select();">{$file['add_your_website']}</textarea></p>
        {/if}
  {if $settings['tellfriend']}
      <h4>{$lang['email_friend']}:</h4>
      <form method="post" action="" id="tell_friend_form">
        <div class="line">
          <p class="left">{$lang['your_name']}</p>
          <p><input name="tell_name" type="text" value="{$session->info['username']}" maxlength="25" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['your_email_address']}</p>
          <p><input name="tell_email" type="text" value="{$session->info['email']}" maxlength="50" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['your_friends_email_address']}</p>
          <p><input name="tell_friend_email" type="text" size="30" maxlength="50" /></p>
        </div>
    {if $settings['image_verification'] == 1}
        <div>
          <p class="bold">{$lang['image_verification']}:</p>
          <div id="tell_image_verification"></div>
        </div>
    {/if}
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    {/if}
    </div>
  {if $settings['report_broken'] == 1}
    <div>
      <form method="post" action="" id="report_broken_form">
        <p>{$lang['what_wrong_file']}</p>
        <p>
          <input type="text" name="report_reason" />
          <input type="submit" value="{$lang['submit']}" />
        </p>
      </form>
    </div>
    {/if}
  </div>
  <script type="text/javascript">
	init_file_info({$file['id']}, {$file['rating']}, {$settings['rate']}, {$settings['before_file_ad_time']});
  </script>
</div>
<iframe src="{$file['file']}" width="100%" height="850" frameborder="0" scrolling="auto" id="file_frame"></iframe>
</body>

<script type="text/javascript">
init_frame();
</script>

</html>
{/template}
