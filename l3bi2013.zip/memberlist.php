{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template member_list}
  
  <div id="main_contents">
    <h2>{$lang['member_list']}</h2>
    <div class="content_box">
  {foreach $txt['members'] as $number => $member}
      <div class="member">
        <img src="{$member['avatar']}" class="avatar" />
        <div class="content">
          <p><a href="{$member['url']}">{$member['name']}</a></p>
          <p>{$lang['played']}: {$member['played']}</p>
          <p>{$lang['comments']}: {$member['comments']}</p>
          <p>{$lang['joined']}: {$member['joined']}</p>
          <p><a href="privatemessages.php?a=compose&amp;u={$member['id']}"><img src="images/send_pm.png" border="0" title="{$lang['pm']}" alt="{$lang['pm']}" /></a></p>
        </div>
      </div>
  {/foreach}
      <div class="clear"></div>
      <div class="txt_right">
        <form action="memberlist.php" method="post">
          <p>{$lang['list_sort_by']}</p>
          <p>
            {$lang['search']}: <input tyle="text" name="n" maxlength="25" value="{$txt['search_tag']}" />
            <input type="submit" value="{$lang['go']}" />
          </p>
        </form>
      </div>
      <div class="pagination">
        {$txt['nav']}
      </div>
    </div>
  </div>
{/template}