/**
 * onArcade 2.4.0
 * Copyright © 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved
 **
 * ONARCADE IS NOT FREE SOFTWARE!
 * http://www.onarcade.com
 **
 * JavaScript template code.
 **/

var template = {

		/*
		 * Score line
		 */
		score_line: '<div class="score_line$(me)">'
			+'<p class="position">$(pos)</p>'
			+'<p class="user"><a href="$(url)">$(username)</a></p>'
			+'<p class="score">$(score)</p>'
			+'<p class="date">$(date)</p>'
			+'</div>',

		/*
		 * Cup score line on file page
		 */
		cup_score_line: '<div class="score_line$(me)">'
				+'<p class="position">$(pos)</p>'
				+'<p class="points">$(points)</p>'
				+'<p class="user"><a href="$(url)">$(username)</a></p>'
				+'<p class="score">$(score)</p>'
				+'<p class="date">$(date)</p>'
				+'</div>',

		/*
		 * Notification in User CP
		 */
		notification: '<div class="notification" id="notification_$(id)"><img src="images/notification_delete.png" class="del_notification" alt="" style="float:right" /><span class="time">$(time)</span> $(notification)</div>',

		/*
		 * Notification in user menu
		 */
		notification_menu: '<div class="notification" id="notification_menu_$(id)"><img src="$(siteurl)images/notification_delete.png" class="del_notification" alt="" /> $(notification)</div>',

		/*
		 * Favorite file in User CP on favorites page
		 */
		favoriteFile: '<div class="file" id="favourite_$(id)">'
			+'<div class="icon"><a href="$(url)"><img src="$(image)" width="$(width)" height="$(height)" alt="$(title)" /></a></div>'
			+'<div class="desc">'
				+'<p class="link"><a href="$(url)">$(title)</a></p>'
				+'<p>$(description)</p>'
				+'<p><img src="images/remove.png" class="click removeFile" title="$(lang_delete)" alt="$(lang_delete)" /></p>'
			+'</div></div>',

		/*
		 * Favorites in user menu
		 */
		favorites_menu: '<p class="favorite"><a href="$(url)">$(title)</a></p>',

		/*
		 * Friend in User CP
		 */
		friend: '<div class="member" id="member_$(id)">'
			+'<div class="content">'
				 +'<p><a href="$(url)">$(username)</a></p>'
				 +'<p>$(name)</p>'
				 +'<p>$(location)</p>'
				 +'<p><img src="images/send_pm.png" class="click send_pm" />'
				 	+' <img src="images/remove.png" class="click remove_friend" title="$(lang_remove_friend)" />'
				 	+' $(accept)</p></div>'
			+'<img class="avatar" src="$(avatar)"></div>',

		/*
		 * Comment on file page
		 */
		comment: '<div class="comment" id="comment_$(id)">'
			+'<img src="$(siteurl)images/report.png" title="$(lang_report)" alt="$(lang_report)" class="report" />'
			+'<p><span class="user">$(user)</span><span class="date">($(date))</span></p>'
			+'<p class="text">$(comment)</p>'
			+'</div>',

		/*
		 * Comment on user profile page
		 */
		profile_comment: '<div class="comment" id="comment_$(id)">'
			+'<p><span class="user">$(user)</span><span class="date">($(date))</span></p>'
			+'<p class="text">$(comment)</p>'
			+'</div>',

		/*
		 * Cup game
		 */
		cup_game: '<div id="game_$(id)">'
			+'<a href="$(url)" target="_blank"><img src="$(image)" title="$(title)" alt="$(title)" /></a>'
			+'<p class="center"><img src="images/remove.png" class="click remove_game" /></p>'
			+'</div>'

};