{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template cp_menu}
      <h2>{$lang['control_panel']}</h2>
      <div id="ucp_menu" class="content_box">
        <ul>
          <li><a href="{$settings['siteurl']}/usercp.php"><img src="images/usercp/home.png" alt="" />{$lang['cp_home']}</a></li>
          <li><a href="{$settings['siteurl']}/usercp.php?a=profile"><img src="images/usercp/profile.png" alt="" />{$lang['edit_profile']}</a></li>
  {if $settings['custom_profile'] == 1}
          <li><a href="{$settings['siteurl']}/usercp.php?a=customize_profile"><img src="images/usercp/customize.png" alt="" />{$lang['customize_profile']}</a></li>
    {/if}
          <li><a href="{$settings['siteurl']}/usercp.php?a=options"><img src="images/usercp/options.png" alt="" />{$lang['edit_options']}</a></li>
          <li><a href="{$settings['siteurl']}/usercp.php?a=emailpassword"><img src="images/usercp/password.png" alt="" />{$lang['edit_email_password']}</a></li>
          <li><a href="{$settings['siteurl']}/usercp.php?a=avatar"><img src="images/usercp/avatar.png" alt="" />{$lang['edit_avatar']}</a></li>
          <li><a href="{$settings['siteurl']}/usercp.php?a=friends"><img src="images/usercp/friends.png" alt="" />{$lang['friends']}</a></li>
          <li><a href="{$settings['siteurl']}/usercp.php?a=favorites"><img src="images/usercp/favourites.png" alt="" />{$lang['favourites']}</a></li>
          <li><a href="{$settings['siteurl']}/privatemessages.php"><img src="images/usercp/pm.png" alt="" />{$lang['private_messages']}</a></li>
        </ul>
      </div>
{/template}

{template cp_main}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['welcome_username']}</h2>
    <div class="content_box">
      <div class="center" style="float: right; width: 125px;">
        <img src="{$session->info['avatar']}" class="avatar" alt="{$lang['avatar']}" />
      </div>
      <div style="float: right;">
        <p>{$lang['email']}: {$session->info['email']}</p>
        <p>{$lang['played']}: {$session->info['played']}</p>
        <p>{$lang['comments']}: {$session->info['comments']}</p>
        <p>{$lang['joined']}: {(format_date($session->info['joined']))}</p>
        <p><a href="{$url->profile($session->user_id,$session->username)}" class="button">{$lang['view_profile']}</a></p>
      </div>
      <div class="clear"></div>
    </div>
    <h2>{$lang['notifications']}</h2>
    <div class="content_box" id="to_notifications">
      <div id="all_notifications"></div>
      <script type="text/javascript">
		notifications.data = {$notifications};
		notifications.init();
      </script>
    </div>
  </div>
{/template}

{template cp_profile}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['edit_profile']}</h2>
    <div class="content_box">
      <form action="" method="post" id="profile_form">
        <div class="line">
          <p class="left">{$lang['name']}:</p>
          <p><input type="text" name="name" maxlength="100" value="{$session->info['name']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['quote']}:</p>
          <p><textarea name="quote">{$session->info['quote']}</textarea></p>
        </div>
        <div class="line">
          <p class="left">{$lang['location']}:</p>
          <p><input type="text" name="location" maxlength="50" value="{$session->info['location']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['gender']}:</p>
          <p>
            <select name="gender">
              <option value="0"></option>
              <option value="1"{$txt['male']}>{$lang['male']}</option>
              <option value="2"{$txt['female']}>{$lang['female']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p class="left">{$lang['birthday']}:</p>
          <p>{$txt['birthday_selection']}</p>
        </div>
        <div class="line">
          <p class="left">{$lang['website']}:</p>
          <p><input type="text" name="website" maxlength="100" value="{$session->info['website']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['msn']}:</p>
          <p><input type="text" name="msn" maxlength="100" value="{$session->info['msn']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['aim']}:</p>
          <p><input type="text" name="aim" maxlength="50" value="{$session->info['aim']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['skype']}:</p>
          <p><input type="text" name="skype" maxlength="50" value="{$session->info['skype']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['yahoo']}:</p>
          <p><input type="text" name="yahoo" maxlength="50" value="{$session->info['yahoo']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['icq']}:</p>
          <p><input type="text" name="icq" maxlength="50" value="{$session->info['icq']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['google_talk']}:</p>
          <p><input type="text" name="google_talk" maxlength="50" value="{$session->info['google_talk']}" /></p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['see_messengers']}:</p>
          <p>
            <select name="see_messengers">
              <option value="0">{$lang['cp_no_one']}</option>
              <option value="1"{$txt['members']}>{$lang['cp_members']}</option>
              <option value="2"{$txt['friends']}>{$lang['friends']}</option>
            </select>
          </p>
        </div>
        <div class="center">
          <input type="submit" value="{$lang['submit']}" />
        </div>
      </form>
    </div>
    <script type="text/javascript">
  $("#profile_form").submit(function() {
    update_profile($(this)); return false;
  });
    </script>
  </div>
{/template}

{template customize_profile}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['edit_options']}</h2>
    <div class="content_box">
      <form action="" method="post" id="profile_form">
        <fieldset>
          <legend>{$lang['background']}</legend>
          <p>
            {$lang['background_color']}:
            #<input type="text" name="gb_background_color" class="small" maxlength="6" value="{$txt['css']['gb_background_color']}" />
            <img src="{$settings['siteurl']}/images/color.png" class="click" alt="" />
          </p>
          <p>{$lang['background_image']}*: <input type="text" name="gb_background_image" value="{$txt['css']['gb_background_image']}" /></p>
          <p>{$lang['fixed']}: <select name="gp_fixed"><option value="0">{$lang['no']}</option><option value="1"{$txt['css']['gp_fixed']}>{$lang['yes']}</option></select></p>
        </fieldset>
        <fieldset>
          <legend>{$lang['profile_background']}</legend>
          <p>
            {$lang['background_color']}:
            #<input type="text" name="pb_background_color" maxlength="6" class="small" value="{$txt['css']['pb_background_color']}" />
            <img src="{$settings['siteurl']}/images/color.png" class="click" alt="" />
            ({$lang['0_transparent']})
          </p>
          <p>{$lang['background_image']}*: <input type="text" name="pb_background_image" value="{$txt['css']['pb_background_image']}" /></p>
          <p>
            {$lang['border']}: <input type="text" name="pb_border_0" class="small" maxlength="2" value="{$txt['css']['pb_border'][0]}" />{$lang['px']}
            <select name="pb_border_1"><option value="0">{$lang['solid']}</option><option value="1"{$txt['css']['pb_border'][1]}>{$lang['dotted']}</option></select>
            #<input type="text" name="pb_border_2" class="small" maxlength="6" value="{$txt['css']['pb_border'][2]}" />
            <img src="{$settings['siteurl']}/images/color.png" class="click" alt="" />
          </p>
        </fieldset>
        <p>{$lang['upload_image_to']}</p>
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    </div>
    <script type="text/javascript">
  color_selector.init();
  $("#profile_form").submit(function() {
    update_customize_profile($(this)); return false;
  });
    </script>
  </div>
{/template}

{template cp_options}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['edit_options']}</h2>
    <div class="content_box">
      <form action="" method="post" id="options_form">
        <div class="line">
          <div class="left">{$lang['template']}:</div>
          <p>{$txt['template']}</p>
        </div>
        <div class="line">
          <p class="left">{$lang['language']}:</p>
          <p>{$txt['language']}</p>
        </div>
        <div class="line">
          <p class="left">{$lang['time_zone']}:</p>
          <p>{$txt['time_zone']}</p>
        </div>
        <fieldset>
          <legend>{$lang['email_notifications']}</legend>
          <p><label><input type="checkbox" name="receiveemails" value="1"{$txt['receiveemails']} /> {$lang['receive_emails_from_admins']}</label></p>
          <p><label><input type="checkbox" name="email_pm" value="1"{$txt['email_pm']} /> {$lang['notify_email_new_pm']}</label></p>
          <p><label><input type="checkbox" name="friend_email" value="1"{$txt['friend_email']} /> {$lang['notify_email_friend']}</label></p>
          <p><label><input type="checkbox" name="comment_email" value="1"{$txt['comment_email']} /> {$lang['notify_email_comment']}</label></p>
        </fieldset>
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    </div>
    <script type="text/javascript">
  $("#options_form").submit(function() {
    update_options($(this)); return false;
  });
    </script>
  </div>
{/template}

{template cp_email_password}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['edit_email_password']}</h2>
    <div class="content_box">
      <form action="" method="post" id="password_form">
        <div class="line">
          <p class="left wide">{$lang['current_password']}</p>
          <p><input type="password" name="current_password" maxlength="25" /></p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['current_email']}</p>
          <p>{$session->info['email']}</p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['new_password']}</p>
          <p><input type="password" name="new_password" maxlength="25" size="20" /> {$lang['cp_optional']}</p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['confirm_new_password']}</p>
          <p><input type="password" name="new_password_2" maxlength="25" /></p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['new_email']}</p>
          <p><input type="text" name="new_email" maxlength="50" /> {$lang['cp_optional']}</p>
        </div>
        <div class="line">
          <p class="left wide">{$lang['confirm_new_email']}</p>
          <p><input type="text" name="new_email_2" maxlength="50" /><p>
        </div>
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    </div>
    <script type="text/javascript">
  $("#password_form").submit(function() {
    update_password($(this)); return false;
  });
    </script>
  </div>
{/template}

{template cp_avatar}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['edit_avatar']}</h2>
    <div class="content_box">
      <p class="bold">{$lang['current_avatar']}</p>
      <p><img src="{$session->info['avatar']}" class="avatar" alt="{$lang['current_avatar']}" /></p>
  {if $settings['avatar_gallery'] == 1}
      <form action="" method="post" id="gallery_form">
        <div class="line">
          <p class="left">{$lang['avatar_galleries']}</p>
          <p>{$txt['galleries']} <input type="submit" value="{$lang['go']}" /></p>
        </div>
      </form>
    {/if}
      <form action="" method="post" enctype="multipart/form-data" id="upload_form">
  {if $settings['remote_avatar'] == 1}
        <div class="line">
          <p class="left">{$lang['url']}:</p>
          <p><input type="text" id="avatar_url" name="avatar_url" /></p>
        </div>
  {/if}
  {if $settings['avatar_uploading'] == 1}
        <div class="line">
          <p class="left">{$lang['avatar_upload']}</p>
          <p><input id="avatar_upload" name="avatar_upload" type="file" /> {$lang['max_avatar_size_kb']}</p>
        </div>
  {/if}
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    </div>
    <script type="text/javascript">
  init_avatar();
    </script>
  </div>
{/template}

{template cp_friends}
  
  <div id="main_contents">
  {show cp_menu}
    <ul class="tab_menu" id="friends_tabs">
      <li><a href="">{$lang['friends']}</a></li>
      <li><a href="">{$lang['friend_requests']}</a></li>
      <li><a href="">{$lang['friend_invites']}</a></li>
    </ul>
    <div class="content_box" id="friends_contents">
      <div></div>
      <div></div>
      <div></div>
    </div>
    <script type="text/javascript">
  friends.friends = {$txt['friends']};
  friends.init();
    </script>
  </div>
{/template}

{template cp_favorites}
  
  <div id="main_contents">
  {show cp_menu}
    <h2>{$lang['favourites']}</h2>
    <div class="content_box" id="favourites">
    </div>
    <script type="text/javascript">
    favorites.files = {$txt['files']};
    favorites.next = {$txt['next']};
    favorites.imageWidth = {$settings['image_width']};
    favorites.imageHeight = {$settings['image_height']};
    favorites.init();
    </script>
  </div>
{/template}

{template pm_menu}
  {show cp_menu}
    <ul class="tab_menu" id="friends_tabs">
      <li><a href="{$settings['siteurl']}/privatemessages.php" {$txt['tab_inbox']}>{$lang['inbox']}</a></li>
      <li><a href="{$settings['siteurl']}/privatemessages.php?f=2" {$txt['tab_sent']}>{$lang['sent_items']}</a></li>
      <li><a href="{$settings['siteurl']}/privatemessages.php?a=compose" {$txt['tab_compose']}>{$lang['compose_message']}</a></li>
    </ul>
{/template}

{template pm_main}
  
  <div id="main_contents">
  {show pm_menu}
    <div class="content_box">
      <form action="" method="post" name="form">
        <div class="tbl_header">
          <p style="width: 20px;">&nbsp;</p>
          <p style="width: 250px;">{$lang['title']}</p>
          <p style="width: 145px;">{$txt['user']}</p>
          <p style="width: 133px;">{$lang['date']}</p>
          <p style="width: 30px;"><input type="checkbox" onclick="check_all(this);" /></p>
        </div>
  {foreach $pm_list as $pm}
        <div class="tbl">
      <p style="width: 20px;">{$pm['status']}</p>
          <p style="width: 250px;"><a href="{$settings['siteurl']}/privatemessages.php?a=read&amp;p={$pm['id']}">{$pm['subject']}</a></p>
          <p class="center" style="width: 145px;">{$pm['user']}</p>
          <p class="center" style="width: 133px;">{$pm['date']}</p>
          <p class="center" style="width: 30px;"><input type="checkbox" name="pm_id[{$pm['id']}]" value="ok" /></p>
        </div>
    {/foreach}
        <div class="txt_right">
          {$lang['selected_messages_do']}
        </div>
      </form>
      <div class="pagination txt_right">
        {$txt['nav']}
      </div>
      <p><img src="{$settings['siteurl']}/images/read.png" width="16" height="16" title="{$lang['read']}" alt="{$lang['read']}" /> - {$lang['read']}</p>
      <p><img src="{$settings['siteurl']}/images/unread.png" width="16" height="16" title="{$lang['unread']}" alt="{$lang['unread']}" /> - {$lang['unread']}</p>
    </div>
  </div>
{/template}

{template pm_read}
  
  <div id="main_contents">
  {show pm_menu}
    <div class="content_box">
      <div class="post">
        <div class="content">
          <p class="header">
            <img src="images/message.png" width="10" height="10" border="0" alt="" />
            {$read_pm['subject']}
            <span>- {$read_pm['date']}</span>
          </p>
          <div class="message">{$read_pm['message']}</div>
          <p class="footer">
            <a href="{$settings['siteurl']}/privatemessages.php?a=compose&amp;r={$read_pm['id']}" class="button">{$lang['reply']}</a>
            <a onclick="return confirm_delete();" href="{$settings['siteurl']}/privatemessages.php?a=delete&amp;p={$read_pm['id']}" class="button">{$lang['delete']}</a>
          </p>
        </div>
        <div class="poster">
          <p>
            <a href="{$read_pm['from_url']}"><img src="{$read_pm['from_user_avatar']}" alt="{$read_pm['from_user_username']}" title="{$read_pm['from_user_username']}" /></a>
          </p>
          <p class="user"><a href="{$read_pm['from_url']}">{$read_pm['from_user_username']}</a></p>
          <p>{$lang['played']}: {$read_pm['from_user_played']}</p>
          <p>{$lang['comments']}: {$read_pm['from_user_comments']}</p>
          <p>{$lang['joined']}: {$read_pm['from_user_joined']}</p>
        </div>
      </div>
    </div>
  </div>
{/template}

{template pm_compose}
  
  <div id="main_contents">
  {show pm_menu}
    <div class="content_box">
  {if isset($compose['message_preview'])}
      <div class="post ucp_pm_preview">
        <div class="content">
          <p class="header">
            <img src="images/message.png" width="10" height="10" border="0" alt="" />
            {$compose['subject']}
          </p>
          <div class="message">{$compose['message_preview']}</div>
        </div>
      </div>
      <div class="separator"></div>
  {/if}
  {if strlen($compose['error'])}
      <div class="error">
        {$compose['error']}
      </div>
  {/if}
      <form action="{$settings['siteurl']}/privatemessages.php?a=compose" method="post" name="compose_form">
        <div class="line">
          <p class="left">{$lang['recipient']}:</p>
          <p><input name="message_recipient" type="text" value="{$compose['recipient']}" maxlength="50" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['title']}:</p>
          <p><input name="message_subject" type="text" value="{$compose['subject']}" maxlength="50" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['message']}:</p>
          <div>
            <div id="bb_code"></div>
            <p><textarea name="message_text" id="message_text" class="post">{$compose['message']}</textarea></p>
          </div>
        </div>
        <p class="center">
          <input type="submit" name="submit" value="{$lang['send_message']}" />
          <input type="submit" name="preview" value="{$lang['preview']}" />
        </p>
      </form>
    </div>
    <script type="text/javascript">
  bb_code.attach("bb_code", "message_text");
    </script>
  </div>
{/template}