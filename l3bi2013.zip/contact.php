{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template contact}
  
  <div id="main_contents">
    <h2>{$lang['contact_us']}</h2>
    <div class="content_box">
      <p>{$lang['contact_us_form']}</p>
  {if strlen($contact['error'])}
      <p class="error">{$contact['error']}</p>
  {/if}
      <form action="{$settings['siteurl']}/contact.php" method="post">
        <div class="line">
          <p class="left">{$lang['name']}:</p>
          <p><input type="text" name="sendername" maxlength="255" value="{$contact['name']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['email']}:</p>
          <p><input type="text" name="senderemail" maxlength="255" value="{$contact['email']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['subject']}:</p>
          <p><input type="text" name="messagesubject" maxlength="255" value="{$contact['subject']}" /></p>
        </div>
        <div>
          <p class="left">{$lang['message']}:</p>
          <p><textarea name="message" class="post">{$contact['message']}</textarea></p>
        </div>
  {if $settings['image_verification'] == 1}
        <div>
          <p class="bold">{$lang['image_verification']}:</p>
          <div id="image_verification"></div>
        </div>
        <script type="text/javascript"> image_verification.attach("image_verification"); </script>
  {/if}
        <p class="center"><input type="submit" name="send" value="{$lang['send']}" /></p>
      </form>
    </div>
  </div>
{/template}