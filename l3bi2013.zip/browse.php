{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template browse}
  <div id="main_contents">
  {if is_array($txt['sub'])}
    <h2>{$lang['subcategories']}</h2>
    <div>
    {foreach $txt['sub'] as $category}
      <div class="cat1">
        <a href="{$category['url']}"><img src="{$settings['siteurl']}/templates/l3bi2013/images/{$category['id']}.png" width="83" height="83" title="{$category['name']}" alt="{$category['name']}" border="0" /></a>
        <a href="{$category['url']}">{$category['name']}</a>
      </div>
    {/foreach}
      <div class="clear"></div>
    </div>
  {/if}
    <h2 class="cat_brea">
      <a href="{$settings['siteurl']}/">{$settings['sitename']}</a>
  {if isset($txt['parent_id'])}
      &gt; <a href="{$txt['parent_url']}">{$txt['parent_title']}</a>
  {/if}
      &gt; {$txt['category_title']}
    </h2>
    <div>
      <div id="right_banner">
<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner2.jpg" alt="" />
</div>
    {foreach $files as $line => $file}
      <div class="browse_file">
        
      {if $file['scores'] == 1}
          <span class="scores"></span>
      {/if}
          <a href="{$file['url']}"><img src="{$file['image']}" width="150" height="115" title="{$file['title']}" alt="{$file['title']}" border="0" /></a>
           <p class="link"><a href="{$file['url']}">{$file['title']}</a></p>
        </div>
  
         
       
  {/foreach}
  <div class="clear"></div>
  <div id="bannerrec" style="padding-top:10px;">
<img src="{$settings['siteurl']}/templates/l3bi2013/images/banner1.jpg" alt="" />
</div>
      <div class="clear"></div>
      <div class="pagination">
        {$txt['nav']}
      </div>
      <div class="txt_right">
        <form name="search" action="{$settings['siteurl']}/search.php" method="post">
          <input type="text" name="t" maxlength="25" size="20" />
          <input type="hidden" name="c" value="{$txt['category_id']}" />
          <input type="submit" value="{$lang['search']}" />
        </form>
        <form name="order" action="" method="post">
          <p>
            {$lang['order_by']}
            <select name="order">
              <option value="title">{$lang['title']}</option>
              <option value="rating" {($order == 'rating' ? 'selected="selected"':'')}>{$lang['rating']}</option>
              <option value="played" {($order == 'played' ? 'selected="selected"':'')}>{$lang['played']}</option>
              <option value="added" {($order == 'added' ? 'selected="selected"':'')}>{$lang['time_added']}</option>
            </select>
            <input type="submit" value="{$lang['go']}" />
          </p>
        </form>
      </div>
    </div>
  </div>
{/template}

{template search}
  
  <div id="main_contents">
    <h2 class="cat_brea"><a href="{$settings['siteurl']}/">{$settings['sitename']}</a> &gt; {$txt['search_term']}</h2>
    <div>
  {if empty($files)}
      <p class="error">{$lang['no_results']}</p>
  {else}
    {foreach $files as $line => $file}
      <div class="browse_file">
        <div class="icon">
      {if $file['scores'] == 1}
          <span class="scores"></span>
      {/if}
          <a href="{$file['url']}"><img src="{$file['image']}" width="150" height="115" title="{$file['title']}" alt="{$file['title']}" border="0" /></a>
          <p class="link"><a href="{$file['url']}">{$file['title']}</a></p>
        </div>
        
      </div>
    {/foreach}
      <div class="clear"></div>
      <div class="arrow_nav">
    {if !empty($txt['previous'])}
        <a href="{$txt['previous']}" class="previous">&lt; {$lang['previous']}</a>
    {/if}
    {if !empty($txt['next'])}
        <a href="{$txt['next']}" class="next">{$lang['next']} &gt;</a>
    {/if}
      </div>
      <div class="txt_right">
        <form name="order" action="{$txt['url']}" method="post">
          <p>
            {$lang['order_by']}
            <select name="order">
              <option value="relevance">{$lang['relevance']}</option>
              <option value="title" {($order == 'title' ? 'selected="selected"':'')}>{$lang['title']}</option>
              <option value="rating" {($order == 'rating' ? 'selected="selected"':'')}>{$lang['rating']}</option>
              <option value="played" {($order == 'played' ? 'selected="selected"':'')}>{$lang['played']}</option>
              <option value="added" {($order == 'added' ? 'selected="selected"':'')}>{$lang['time_added']}</option>
            </select>
            <input type="submit" value="{$lang['go']}" />
          </p>
        </form>
      </div>
  {/if}
    </div>
  </div>
{/template}