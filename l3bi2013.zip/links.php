{comment}
onArcade 2.4.0
Copyright (c) 2006-2011 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template links}
  {show menu}
  <div id="main_contents">
    <h2>{$lang['links']}</h2>
    <div class="content_box">
  {foreach $links as $link}
      <p><a href="{$link['url']}" onclick="return link_out({$link['id']});">{$link['title']}</a> - {$link['description']}</p>
  {/foreach}
      <p class="center"><a href="{$settings['siteurl']}/links.php?a=add" class="button">{$lang['add_link']}</a></p>
    </div>
  </div>
{/template}

{template add_link}
  {show menu}
  <div id="main_contents">
    <h2>{$lang['add_link']}</h2>
    <div class="content_box">
  {if strlen($link['error'])}
      <p class="error">{$link['error']}</p>
  {/if}
      <form action="" method="post" name="form">
        <div class="line">
          <p class="left">{$lang['title']}:</p>
          <p><input type="text" name="link_title" maxlength="255" value="{$link['title']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['url']}:</p>
          <p><input type="text" name="link_url" maxlength="255" value="{$link['url']}" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['description']}:</p>
          <p><textarea name="link_description">{$link['description']}</textarea></p>
        </div>
        <div class="line">
          <p class="left">{$lang['email']}:</p>
          <p><input type="text" name="link_email" maxlength="255" value="{$link['email']}" /></p>
        </div>
  {if $settings['image_verification'] == 1}
        <div>
          <p class="bold">{$lang['image_verification']}:</p>
          <div id="image_verification"></div>
        </div>
        <script type="text/javascript"> image_verification.attach("image_verification"); </script>
  {/if}
        <p class="center"><input type="submit" name="submit" value="{$lang['submit']}" /></p>
      </form>
    </div>
  </div>
{/template}